package com.example.myrestaurant

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}

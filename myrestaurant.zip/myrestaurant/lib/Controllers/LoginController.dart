import 'package:get/get.dart';

class LoginController extends GetxController {
  final mobilenumber = "".obs;
}

import 'package:get/get.dart';

class ItemController extends GetxController {
  final catid = "".obs;
  final itemname = "".obs;
  final itemid = "".obs;
  final itemdescription = "".obs;
  final itemprice = "".obs;
  final itemtype = "".obs;
}

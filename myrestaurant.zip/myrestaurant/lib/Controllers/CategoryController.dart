import 'package:get/get.dart';

class CategoryController extends GetxController {
  final catname = "".obs;
  final catid = "".obs;
  final catphotourl = "".obs;
}
